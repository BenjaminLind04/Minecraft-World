variabel=read()
print(variabel)
