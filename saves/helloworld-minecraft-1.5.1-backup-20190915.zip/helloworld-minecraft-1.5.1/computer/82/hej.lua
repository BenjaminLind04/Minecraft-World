while not rs.getInput("back", true) do
  os.pullEvent()
  print("Hello")
end
