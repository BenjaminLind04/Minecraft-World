shell.run("rs.lua")
