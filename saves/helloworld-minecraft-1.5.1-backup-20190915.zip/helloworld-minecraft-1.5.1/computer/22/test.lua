t = turtle
t.forward()
t.turnRight()
t.forward()
t.turnLeft()
for i=1,5 do
    t.forward()
end
t.turnLeft()
t.forward()
t.turnRight()
for i=1,3 do
    t.forward()
end
