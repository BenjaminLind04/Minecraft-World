print("Denna turtle är låst")

while true do 
    os.pullEventRaw()
end


