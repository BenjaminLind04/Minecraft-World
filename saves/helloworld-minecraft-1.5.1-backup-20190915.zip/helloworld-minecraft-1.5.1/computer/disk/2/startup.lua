print("unlocked")
