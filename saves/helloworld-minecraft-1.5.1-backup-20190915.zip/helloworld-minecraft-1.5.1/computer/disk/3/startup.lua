print("Unlocked! =D")
