
print("Den här turtlen är låst.")

while true do
    os.pullEventRaw()
end
