t=turtle

t.forward()
t.turnRight()
t.forward()
t.turnLeft()
for i=1,5 do
    t.forward()
end
t.turnLeft()
t.forward()
t.turnRight()
t.forward()
t.forward()
t.forward()
