local m = peripheral.wrap("bottom")

m.clear()
m.setTextScale(3)

m.setTextColor(colors.red)
m.setCursorPos(1,2)
m.write("Tillbaka till")
m.setCursorPos(5,3)
m.write("lobbyn")
