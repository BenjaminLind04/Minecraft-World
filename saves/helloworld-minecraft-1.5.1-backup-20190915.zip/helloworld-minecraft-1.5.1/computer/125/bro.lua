for i=1,9 do
    turtle.forward()
    turtle.up()
    turtle.placeDown()
end
