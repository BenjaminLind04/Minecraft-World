while true do
    term.clear()
    os.pullEvent()
end
