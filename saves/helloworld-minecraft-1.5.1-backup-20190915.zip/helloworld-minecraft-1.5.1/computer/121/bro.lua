for i=1,7 do
    turtle.forward()
    turtle.placeDown()
end

for i=1,5 do
    turtle.place()
    turtle.up()
    turtle.forward()
end

