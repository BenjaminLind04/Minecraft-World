ord1 = "hejsan"
ord2 = "h"
compare= string.match(ord1, ord2)
print(compare)
