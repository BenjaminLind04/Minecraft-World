if peripheral.isPresent("right") then
turtle.equipRight()
turtle.equipRight()
else
turtle.equipRight()
end

