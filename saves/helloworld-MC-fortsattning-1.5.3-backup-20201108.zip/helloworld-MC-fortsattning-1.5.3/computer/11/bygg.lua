
for i=1, 25 do
turtle.place()
turtle.back()
end
