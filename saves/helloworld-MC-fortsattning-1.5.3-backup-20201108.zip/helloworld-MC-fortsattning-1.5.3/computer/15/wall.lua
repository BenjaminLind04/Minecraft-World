turtle.place()
turtle.back()

