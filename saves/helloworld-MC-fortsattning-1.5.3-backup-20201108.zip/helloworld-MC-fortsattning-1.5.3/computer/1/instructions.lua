monitor = peripheral.wrap()

term.clear()
monitor.clear()
term.setCursorPos(1, 2)
print("Skriv upp layouten här leo")
