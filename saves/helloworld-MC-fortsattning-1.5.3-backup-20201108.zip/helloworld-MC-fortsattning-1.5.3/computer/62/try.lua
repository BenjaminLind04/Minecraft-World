redstone.setOutput("bottom",true)
