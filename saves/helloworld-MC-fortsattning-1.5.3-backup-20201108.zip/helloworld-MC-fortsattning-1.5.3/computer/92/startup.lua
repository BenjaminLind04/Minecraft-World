turtle.equipRight()
