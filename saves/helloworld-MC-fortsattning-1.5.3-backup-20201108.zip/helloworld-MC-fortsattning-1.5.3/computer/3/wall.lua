turtle.up()
for i=1, 32 do
  turtle.placeDown()
  turtle.forward()
end
