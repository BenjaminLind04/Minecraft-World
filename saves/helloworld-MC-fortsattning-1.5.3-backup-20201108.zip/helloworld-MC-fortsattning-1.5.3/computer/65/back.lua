turtle.back()
turtle.turnRight()
for i=1, 6 do
 turtle.back()
end
 turtle.turnLeft()
for i=1, 3 do
 turtle.back()
end
