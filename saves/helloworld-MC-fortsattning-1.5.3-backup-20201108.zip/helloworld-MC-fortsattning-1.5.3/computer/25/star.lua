while true do
 shell.run("monitor", "left", "secret/alongtimeago")
 sleep(1)
 end
