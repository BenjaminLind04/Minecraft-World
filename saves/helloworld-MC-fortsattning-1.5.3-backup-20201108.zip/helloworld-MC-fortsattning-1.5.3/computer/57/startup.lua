print("I have awoken!")
