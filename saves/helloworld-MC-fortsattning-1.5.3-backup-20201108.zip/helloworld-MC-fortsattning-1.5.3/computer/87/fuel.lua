x = turtle.getFuelLevel()
print(x)
