while true do
print("Emil gillar kossor")
sleep(0.5)
end

