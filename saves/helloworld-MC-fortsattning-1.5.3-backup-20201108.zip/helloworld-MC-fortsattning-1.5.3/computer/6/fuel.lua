m = turtle.getFuelLevel()
print(m)
