for i = 1,32 do 
turtle.place()
turtle.back()
end
