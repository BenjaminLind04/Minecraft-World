turtle.turnRight()

for i =1,3 do
turtle.forward()
end
turtle.turnRight()
redstone.setOutput("front", true)
turtle.back()
