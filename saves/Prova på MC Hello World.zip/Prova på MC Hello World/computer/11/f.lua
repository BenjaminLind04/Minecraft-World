turtle.forward()
turtle.up()
