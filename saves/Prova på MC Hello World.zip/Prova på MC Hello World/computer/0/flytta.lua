turtle.forward()
turtle.forward()
turtle.forward()
turtle.forward()
